### Альтернативный запуск

ansible-playbook playbook.yml -e "client1=10.10.0.4 server1=10.10.0.3" , где

напрвление трафика проверки ***client -> server***
